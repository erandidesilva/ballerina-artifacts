Description
===========
This sample will print 'Hello world' in the console and exit.


How to run this sample
======================
bin$ ./ballerina run main ../samples/helloWorld/helloWorld.bal
